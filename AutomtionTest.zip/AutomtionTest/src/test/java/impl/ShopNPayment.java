package impl;

import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import testPac.AbstractSteps;

import java.time.Duration;

public class ShopNPayment extends AbstractSteps {

    public void clickCategoryMenu(){
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//section[@id='categorymenu']//a[contains(text(),'Apparel & accessories')]")));
        WebElement categoryMenu = getDriver().findElement(By.xpath("//section[@id='categorymenu']//a[contains(text(),'Apparel & accessories')]"));
        categoryMenu.click();
        logger.log(Status.PASS,"Clicked on Apparel & accessories Category");
    }

    public void clickProduct(String val){
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//div[@id='maincontainer']//a[contains(text(),'"+val+"')]")));
        WebElement product = getDriver().findElement(By.xpath("//div[@id='maincontainer']//a[contains(text(),'"+val+"')]"));
        product.click();
        logger.log(Status.PASS,"Clicked on Product sub Category: "+val);
    }

    public void addProductToCart(){
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("(//div[@class='contentpanel']//a[@title='Add to Cart'])[1]")));
        WebElement addProduct = getDriver().findElement(By.xpath("(//div[@class='contentpanel']//a[@title='Add to Cart'])[1]"));
        addProduct.click();
        logger.log(Status.PASS,"Clicked on Add to Cart Button");
    }

    public void clickCart(String val){
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@class='cart']")));
        WebElement productName = getDriver().findElement(By.xpath("//div[@id='product_details']//span"));
        if(productName.getText().contains(val)){
            logger.log(Status.PASS,"Correct Product Confirmaton in Cart Page. Product Name: "+ val);
        }else{
            logger.log(Status.FAIL,"Wrong Product in Cart Page");
        }
        WebElement cartBtn = getDriver().findElement(By.xpath("//a[@class='cart']"));
        cartBtn.click();
        logger.log(Status.PASS,"Clicked on Cart Button");
    }

    public void clickCheckout(){
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//a[@id='cart_checkout2']")));
        WebElement checkOutBtn = getDriver().findElement(By.xpath("//a[@id='cart_checkout2']"));
        checkOutBtn.click();
        logger.log(Status.PASS,"Clicked on Checkout Button");
    }

    public void confirmProducts(String val){
        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//table[contains(@class,'confirm_products')]//td[2]")));
        WebElement productDetails = getDriver().findElement(By.xpath("//table[contains(@class,'confirm_products')]//td[2]"));
        if(productDetails.getText().contains(val)){
            logger.log(Status.PASS,"Correct Product Confirmation in Payment Page");
        }else{
            logger.log(Status.FAIL,"Wrong Product seen in Payment Page");
        }
        WebElement checkOutBtnFinal = getDriver().findElement(By.xpath("//button[@id='checkout_btn']"));
        checkOutBtnFinal.click();
        logger.log(Status.PASS,"Clicked on Final Checkout Button");
    }

    public void confirmOrderPlaced() {

        WebDriverWait wait = new WebDriverWait(getDriver(), Duration.ofSeconds(10));
        wait.until(ExpectedConditions.presenceOfElementLocated(By.xpath("//span[@class='maintext']")));
        WebElement verifyAccountCreation = getDriver().findElement(By.xpath("//span[@class='maintext']"));
        if (verifyAccountCreation.getText().trim().equals("YOUR ORDER HAS BEEN PROCESSED!")) {
            logger.log(Status.PASS, "Order Placed Successfully");
        } else{
            logger.log(Status.FAIL, "Order Not Placed");
        }
    }

}
